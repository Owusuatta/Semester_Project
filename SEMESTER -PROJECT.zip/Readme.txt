NAME:  OWUSU ATTA FRANCIS
CLASS: BSC. INFORMATION TECHNOLOGY (L100A)
INDEX NUMBER: UEB3207322
PROJECT : SCHOOL MANAGEMENT SYSYTEM

	PROJECT DESCRIPTION- SCHOOL MANAGEMENT SYSYTEM
School Management System project can be used to manage and track student 
performance, attendance, and grades. The School Management System project 
aims to develop a School Management System in C++ that can be used by schoolsto manage their daily operations. The system will enable the school to store, 
manage, and access student records, teacher records, course information, exam 
schedules, and other important data related to the activities in the school.
TechnologiesRequired:C++programminglanguage,ObjectOriented
Programming(OOPs),RelationalDatabaseManagementSystem(RDBMS),Data
Structures,andAlgorithms.
